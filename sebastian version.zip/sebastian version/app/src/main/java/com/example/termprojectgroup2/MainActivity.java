package com.example.termprojectgroup2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements ImageAdapter.ItemClickListener{
    Integer[] icons = {R.drawable.add,R.drawable.update,R.drawable.borrow,R.drawable.tracker};
    ImageAdapter adapter;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int numOfCol = 4;
        Button btnTest = findViewById(R.id.btnCreate);
        Button btnUpdate = findViewById(R.id.btnUpdate);
        Button btnDelete = findViewById(R.id.btnDelete);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this,numOfCol));
        adapter = new ImageAdapter(this,icons);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);

        btnTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, CreateUser.class));
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, ChooseUser.class));
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, ChooseUserDelete.class));
            }
        });
    }



    @Override
    public void onItemClick(View view, int position) {
        switch (position) {
            case 1:
                startActivity(new Intent(MainActivity.this,UpdateActivity.class));
                break;
            case 2:
                startActivity(new Intent(MainActivity.this,BorrowActivity.class));
                break;
            case 3:
                startActivity(new Intent(MainActivity.this,TrackerActivity.class));
                break;
        }
    }
}