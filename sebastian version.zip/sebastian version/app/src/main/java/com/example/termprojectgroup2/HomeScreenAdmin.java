package com.example.termprojectgroup2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HomeScreenAdmin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen_admin);
    }
}