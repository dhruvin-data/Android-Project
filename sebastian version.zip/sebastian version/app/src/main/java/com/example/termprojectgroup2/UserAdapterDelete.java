package com.example.termprojectgroup2;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UserAdapterDelete extends RecyclerView.Adapter<UserAdapterDelete.MyViewHolder> {
    ArrayList<String> userName, DoB, password, address, role, email;
    ArrayList<Integer> id;
    Context context;
    dbUser dbUserDelete;
    public UserAdapterDelete(Context context, ArrayList<Integer> id, ArrayList<String> userName, ArrayList<String> DoB, ArrayList<String> password, ArrayList<String> address
            , ArrayList<String> role, ArrayList<String> email){
        this.context = context;
        this.id = id;
        this.userName = userName;
        this. DoB = DoB;
        this.password = password;
        this.address = address;
        this.role = role;
        this.email = email;
    }
    @NonNull
    @Override
    public UserAdapterDelete.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.user_row,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserAdapterDelete.MyViewHolder holder, int position) {
        holder.btnDeleteUserRow.setText("Delete");
        holder.idInt = (id.get(position));
        holder.txtUserNameT.setText(userName.get(position));
        holder.txtRole.setText(role.get(position));
        holder.userNameStr = userName.get(position);
        holder.DoBStr = DoB.get(position);
        holder.passwordStr = password.get(position);
        holder.addressStr = address.get(position);
        holder.roleStr = role.get(position);
        holder.emailStr = email.get(position);
        holder.btnDeleteUserRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //System.out.println("test");
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Delete User");
                builder.setMessage("Are you sure you want to delete user " + holder.userNameStr + "?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dbUserDelete = new dbUser(context);
                        dbUserDelete.deleteUser(holder.idInt);
                        context.startActivity(new Intent(context, ChooseUserDelete.class));
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                builder.create().show();
            }
        });
    }

    @Override
    public int getItemCount() { return userName.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtUserNameT;
        TextView txtRole;
        Button btnDeleteUserRow;
        String userNameStr, DoBStr, passwordStr, addressStr, roleStr, emailStr;
        int idInt;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtUserNameT = itemView.findViewById(R.id.txtUsernameT);
            txtRole = itemView.findViewById(R.id.txtRole);
            btnDeleteUserRow = itemView.findViewById(R.id.btnUpdateUserRow);
            //btnDeleteUserRow.setText("Delete");
        }
    }


}
