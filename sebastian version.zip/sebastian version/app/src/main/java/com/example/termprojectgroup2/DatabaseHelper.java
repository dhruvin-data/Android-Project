package com.example.termprojectgroup2;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    final static String DATABASE_NAME = "Information.db";
    final static int DATABASE_VERSION = 2;
    final static String TABLE1_Name = "User";
    final static String T1COL1 = "Id";
    final static String T1COL2 = "Username";
    final static String T1COL3 = "DoB";
    final static String T1COL4 = "Password";
    final static String T1COL5 = "Address";
    final static String T1COL6 = "Role";
    final static String T1COL7 = "Email";


    final static String TABLE2_Name = "Books";
    final static String T2COL1 = "Id";
    final static String T2COL2 = "Title";
    final static String T2COL3 = "Description";
    final static String T2COL4 = "Authors";
    final static String T2COL5 = "Genres";
    final static String T2COL6 = "Publisher";
    final static String T2COL7 = "PublicationYear";
    final static String T2COL8 = "Price";
    final static String T2COL9 = "Status";
    final static String T2COL10 = "Owner";

//    final static String TABLE3_Name = "Tracking";
//    final static String T3COL1 = "UserID";
//    final static String T3COL2 = "BookID";
//    final static String T3COL3 = "CurrentPage";
//    final static String T3COL4 = "ReadingStatus";
//
//    final static String TABLE4_Name = "Messages";
//    final static String T4COL1 = "User1ID";
//    final static String T4COL2 = "User2ID";
//    final static String T4COL1 = "MessageTime";
//    final static String T4COL3 = "Message";
//
//
//    final static String TABLE6_Name = "UserBorrowBook";
//    final static String T6COL1 = "UserID";
//    final static String T6COL2 = "BookID";

    final static String TABLE7_Name = "UserGenres";
    final static String T7COL1 = "UserID";
    final static String T7COL2 = "Genres";



    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE1_Name + "(" + T1COL1 + " INTEGER PRIMARY KEY," +
                T1COL2 + " TEXT," + T1COL3 + " TEXT," + T1COL4 + " Text," + T1COL5 +
                " Text," + T1COL6 + " TEXT," + T1COL7 + " Text)";
        db.execSQL(query);
        query = "CREATE TABLE " + TABLE2_Name + "(" + T2COL1 + " INTEGER PRIMARY KEY," +
                T2COL2 + " TEXT," + T2COL3 + " TEXT," + T2COL4 + " Text," + T2COL5 +
                " Text," + T2COL6 + " Text," + T2COL7 + " Text," + T2COL8 + " Text," + T2COL9 + " Text," + T2COL10 + " Text)";
        db.execSQL(query);
        query = "CREATE TABLE " + TABLE7_Name + "(" + T7COL1 + " INTEGER," +
                T7COL2 + " TEXT,"+ "PRIMARY KEY (" + T7COL1 + "," + T7COL2 +"), FOREIGN KEY (" + T7COL1 + ") " +
                "REFERENCES User(Id) ON DELETE CASCADE)" ;
        db.execSQL(query);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE1_Name);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE2_Name);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE7_Name);
        onCreate(db);
    }

}
