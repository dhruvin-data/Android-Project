package com.example.termprojectgroup2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class dbUser extends DatabaseHelper{

    Context context;
    //DatabaseHelper dbhelper = new DatabaseHelper(context);

    public dbUser(Context context){
        super(context);
        this.context = context;

    }

    public long insertUser(String userName, String DoB, String password, String address, String role, String email){
        try{
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(T1COL2,userName);
            values.put(T1COL3,DoB);
            values.put(T1COL4,password);
            values.put(T1COL5,address);
            values.put(T1COL6,role);
            values.put(T1COL7,email);
            long id = db.insert(TABLE1_Name,null,values);
            System.out.println(id);
            return id;
        }
        catch (Exception e){
            e.printStackTrace();
            return -1;
        }

    }

    public Cursor getAllUsers(){
        String query = "select * from " + TABLE1_Name;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(query,null);
        }
        return cursor;

    }

    public void deleteAllUsers(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + TABLE1_Name);
    }

    public long updateUser(int id, String userName, String DoB, String password, String address, String role, String email){
        try{
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(T1COL2,userName);
            values.put(T1COL3,DoB);
            values.put(T1COL4,password);
            values.put(T1COL5,address);
            values.put(T1COL6,role);
            values.put(T1COL7,email);
            System.out.println(id);
            System.out.println(userName + DoB + password + address + role + email);
            long result = db.update(TABLE1_Name,values, "Id=?", new String[]{String.valueOf((id))});

            return result;

        }
        catch (Exception e){
            e.printStackTrace();
            return -1;
        }
    }

    public void deleteUser(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE1_Name,"Id=?", new String[]{String.valueOf((id))});
    }

}
