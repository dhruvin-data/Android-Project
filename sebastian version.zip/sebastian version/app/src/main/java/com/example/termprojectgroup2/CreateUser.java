package com.example.termprojectgroup2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class CreateUser extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user);

        Button btnConfirm = findViewById(R.id.btnConfirm);
        Button btnGoBack = findViewById(R.id.btnGoBack);
        EditText etxtUserName = findViewById(R.id.etxtUsername);
        EditText etxtBirthday = findViewById(R.id.etxtBirthday);
        EditText etxtAddress = findViewById(R.id.etxtAddress);
        EditText etxtEmail = findViewById(R.id.etxtEmail);
        RadioButton rbAdmin = findViewById(R.id.rbAdmin);
        RadioButton rbUser = findViewById(R.id.rbUser);
        RadioButton rbModerator = findViewById(R.id.rbModerator);
        EditText etxtPassword = findViewById(R.id.etxtPassword);

        dbUser dbu = new dbUser(CreateUser.this);

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //boolean isAdmin = false;
                String role = "";
                if(rbAdmin.isChecked()){
                    role = "Admin";
                }
                if(rbUser.isChecked()){
                    role = "User";
                }
                if(rbModerator.isChecked()){
                    role = "Moderator";
                }
                long row = dbu.insertUser(etxtUserName.getText().toString(),
                               etxtBirthday.getText().toString(),
                               etxtPassword.getText().toString(),
                               etxtAddress.getText().toString(),
                               role,
                               etxtEmail.getText().toString());

                if(row > 0){
                    Toast.makeText(CreateUser.this,
                            "User is added successfully", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(CreateUser.this,
                            "User is not added", Toast.LENGTH_SHORT).show();
                }
            }


        });

        btnGoBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CreateUser.this, MainActivity.class));
            }
        });

    }
}