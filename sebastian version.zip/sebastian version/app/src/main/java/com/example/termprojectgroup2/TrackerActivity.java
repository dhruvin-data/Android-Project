package com.example.termprojectgroup2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class TrackerActivity extends AppCompatActivity implements ImageAdapter.ItemClickListener{
    Integer[] icons = {R.drawable.add,R.drawable.update,R.drawable.borrow,R.drawable.tracker};
    ImageAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracker);

        int numOfCol = 4;

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this,numOfCol));
        adapter = new ImageAdapter(this,icons);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onItemClick(View view, int position) {
        switch (position) {
            case 0:
                startActivity(new Intent(TrackerActivity.this,MainActivity.class));
                break;
            case 1:
                startActivity(new Intent(TrackerActivity.this,UpdateActivity.class));
                break;
            case 2:
                startActivity(new Intent(TrackerActivity.this,BorrowActivity.class));
                break;
        }
    }
}