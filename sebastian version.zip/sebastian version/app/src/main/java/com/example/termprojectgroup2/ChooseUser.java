package com.example.termprojectgroup2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class ChooseUser extends AppCompatActivity {

    ArrayList<String> userNames, DoB, password, address, role, email;
    ArrayList<Integer> id;
    dbUser dbuser;
    Cursor cursor;
    RecyclerView tableUser;
    UserAdapter userAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_user);
        id = new ArrayList<>();
        userNames = new ArrayList<>();
        DoB = new ArrayList<>();
        password = new ArrayList<>();
        address = new ArrayList<>();
        role = new ArrayList<>();
        email = new ArrayList<>();
        dbuser = new dbUser(ChooseUser.this);
        cursor = dbuser.getAllUsers();
        tableUser = findViewById(R.id.tableUser);
        fillArray();
        if(userNames.size()>0){
            userAdapter = new UserAdapter(ChooseUser.this, id, userNames, DoB, password, address, role, email);
            tableUser.setAdapter(userAdapter);
            tableUser.setLayoutManager(new LinearLayoutManager(ChooseUser.this));
        }

    }

    public void fillArray(){
        if(cursor.getCount() == 0){
            Toast.makeText(ChooseUser.this, "there are not users registered", Toast.LENGTH_SHORT).show();
        }
        else{
            while(cursor.moveToNext()){
                id.add(cursor.getInt(0));
                userNames.add(cursor.getString(1));
                DoB.add(cursor.getString(2));
                password.add(cursor.getString(3));
                address.add(cursor.getString(4));
                role.add(cursor.getString(5));
                email.add(cursor.getString(6));
                System.out.println(cursor.getString(1));
            }
        }
        //dbuser.deleteAllUsers();
    }
}