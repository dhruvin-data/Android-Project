package com.example.termprojectgroup2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.MyViewHolder> {
    ArrayList<String> userName, DoB, password, address, role, email;
    ArrayList<Integer> id;
    Context context;
    public UserAdapter(Context context, ArrayList<Integer> id, ArrayList<String> userName, ArrayList<String> DoB, ArrayList<String> password,ArrayList<String> address
                ,ArrayList<String> role, ArrayList<String> email){
        this.context = context;
        this.id = id;
        this.userName = userName;
        this. DoB = DoB;
        this.password = password;
        this.address = address;
        this.role = role;
        this.email = email;
    }
    @NonNull
    @Override
    // This is a function that will be executed when the component is created
    // (first it would be the constructor and then this function is executed)
    // Fill the whole table (The inflate function will fill the entire table)
    public UserAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.user_row,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    // It's a function that is executed every time an element is added to the table
    // It's receiving the position as a parameter, it's the position of the element that is inserting the table
    public void onBindViewHolder(@NonNull UserAdapter.MyViewHolder holder, int position) {
        holder.idInt = (id.get(position));
        holder.txtUserNameT.setText(userName.get(position));
        holder.txtRole.setText(role.get(position));
        holder.userNameStr = userName.get(position);
        holder.DoBStr = DoB.get(position);
        holder.passwordStr = password.get(position);
        holder.addressStr = address.get(position);
        holder.roleStr = role.get(position);
        holder.emailStr = email.get(position);
        holder.btnUpdateUserRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context,UpdateUserInfo.class);
                intent.putExtra("id", holder.idInt);
                intent.putExtra("userName", holder.userNameStr);
                intent.putExtra("DoB", holder.DoBStr);
                intent.putExtra("password", holder.passwordStr);
                intent.putExtra("address", holder.addressStr);
                intent.putExtra("role", holder.roleStr);
                intent.putExtra("email", holder.emailStr);

                context.startActivity(intent);
            }
        });
    }

    @Override
    // It will tell the program how many record there are, so that it can automatically fill them out
    // and create that number of rows in the table
    public int getItemCount() {
        return userName.size();
    }

    // Create a class for each row of the table
    // Each row has a textView and button
    // Each row will have its own constructor
    // Each row will have its own reference to its "TextView.txtUserNameT"
    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtUserNameT;
        TextView txtRole;
        Button btnUpdateUserRow;
        String userNameStr, DoBStr, passwordStr, addressStr, roleStr, emailStr;
        int idInt;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtUserNameT = itemView.findViewById(R.id.txtUsernameT);
            txtRole = itemView.findViewById(R.id.txtRole);
            btnUpdateUserRow = itemView.findViewById(R.id.btnUpdateUserRow);
        }
    }
}
