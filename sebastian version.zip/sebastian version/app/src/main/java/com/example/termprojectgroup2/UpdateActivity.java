package com.example.termprojectgroup2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity implements ImageAdapter.ItemClickListener{
    Integer[] icons = {R.drawable.add,R.drawable.update,R.drawable.borrow,R.drawable.tracker};
    ImageAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        int numOfCol = 4;

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this,numOfCol));
        adapter = new ImageAdapter(this,icons);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onItemClick(View view, int position) {
        switch (position) {
            case 0:
                startActivity(new Intent(UpdateActivity.this,MainActivity.class));
                break;
            case 2:
                startActivity(new Intent(UpdateActivity.this,BorrowActivity.class));
                break;
            case 3:
                startActivity(new Intent(UpdateActivity.this,TrackerActivity.class));
                break;
        }
    }
}