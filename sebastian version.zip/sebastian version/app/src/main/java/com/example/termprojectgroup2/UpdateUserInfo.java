package com.example.termprojectgroup2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class UpdateUserInfo extends AppCompatActivity {
    EditText editTextTextPersonName, editTextTextPassword, editTextDate, editTextTextPostalAddress,
            editTextTextEmailAddress;
    RadioButton radioButton, radioButton2, radioButton3;
    Button btnConfirmUpdate, btnGoBackUpdate;
    dbUser db_user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_user_info);

        editTextTextPersonName = findViewById(R.id.editTextTextPersonName);
        editTextTextPassword = findViewById(R.id.editTextTextPassword);
        editTextDate = findViewById(R.id.editTextDate);
        editTextTextPostalAddress = findViewById(R.id.editTextTextPostalAddress);
        editTextTextEmailAddress = findViewById(R.id.editTextTextEmailAddress);
        radioButton = findViewById(R.id.radioButton);
        radioButton2 = findViewById(R.id.radioButton2);
        radioButton3 = findViewById(R.id.radioButton3);
        btnConfirmUpdate = findViewById(R.id.btnConfirmUpdate);
        db_user = new dbUser(UpdateUserInfo.this);
        btnGoBackUpdate = findViewById(R.id.btnGoBackUpdate);


        if(getIntent().hasExtra("userName")){
            editTextTextPersonName.setText(getIntent().getStringExtra("userName"));
        }
        if(getIntent().hasExtra("DoB")){
            editTextDate.setText(getIntent().getStringExtra("DoB"));
        }
        if(getIntent().hasExtra("password")){
            editTextTextPassword.setText(getIntent().getStringExtra("password"));
        }
        if(getIntent().hasExtra("address")){
            editTextTextPostalAddress.setText(getIntent().getStringExtra("address"));
        }if(getIntent().hasExtra("email")){
            editTextTextEmailAddress.setText(getIntent().getStringExtra("email"));
        }
        if(getIntent().hasExtra("role")){
            if(getIntent().getStringExtra("role").equals("User")){
                radioButton.toggle();
            }
            if(getIntent().getStringExtra("role").equals("Moderator")){
                radioButton2.toggle();
            }
            if(getIntent().getStringExtra("role").equals("Admin")){
                radioButton3.toggle();
            }
        }

        btnConfirmUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String role = "";
                if(radioButton.isChecked()){
                    role = "User";
                }
                if(radioButton2.isChecked()){
                    role = "Moderator";
                }
                if(radioButton3.isChecked()){
                    role = "Admin";
                }
                if(getIntent().hasExtra("id")){
                    db_user.updateUser(getIntent().getIntExtra("id",0), editTextTextPersonName.getText().toString(),
                            editTextDate.getText().toString(), editTextTextPassword.getText().toString(), editTextTextPostalAddress.getText().toString(), role,
                            editTextTextEmailAddress.getText().toString());
                    Toast.makeText(UpdateUserInfo.this,
                            "User was uploaded successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnGoBackUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(UpdateUserInfo.this, ChooseUser.class));
            }
        });


    }
}